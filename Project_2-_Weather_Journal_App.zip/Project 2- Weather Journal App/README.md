The weather journal app for udacity's professional track

This page provides the user with:
-Weather state by entering postal code
-Date of the day
-Some input that he/she enters

This page gets data from openwathermap.org with ana API key and saves data in the local server ...
then it proceeds by taking input from the user of how they feel ...
and finally it rovides him by getting these collected data (Date, Temprature, Input text) from the local server to the UI dynamically.

Finally some error catching and handling methods were added to help the user and maintain the stability of the page.
