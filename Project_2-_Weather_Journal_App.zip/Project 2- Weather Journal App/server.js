// Setup empty JS object to act as endpoint for all routes
let projectData = {};

// Requiring express
const express = require('express');

// Start up an instance of app
const app = express();

//requiring cors 
const cors = require('cors');
app.use(cors());

//requiring body-parser.
const Body_Parser = require('body-parser');
app.use(Body_Parser.urlencoded({ extended: false }));
app.use(Body_Parser.json());


//pointing to the folder of the project static files
app.use(express.static('website'));

//sitting a contant of the port
const port = 3000;

//Seting-up the Server
const server = app.listen(port, () => console.log("Server running on:" + '\n'  + "http://localhost:" + port));

//GET request
app.get('/getAll',(request, response) => {
    response.send(projectData);
});



//POST request
app.post('/sendAll', (request, response) => {
    projectData = request.body;
    response.send(projectData);
});
