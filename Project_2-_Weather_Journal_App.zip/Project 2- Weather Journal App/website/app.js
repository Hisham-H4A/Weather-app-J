//getting elements by there id to work with
const zipElement = document.getElementById('zip');
const userContent = document.getElementById('feelings');

//stting up api url constants
const Link = "https://api.openweathermap.org/data/2.5/weather?zip=";
const Api = "541521236a2510bd17992e5d8a6bc018";

// Create a new date instance dynamically with JS
let dt = new Date();
let todayDate = (dt.getMonth() + 1) + '.' + dt.getDate() +'.'+ dt.getFullYear() + ' (M/D/Y) ';

//adding the generator function to the button on click
const generatorB = document.getElementById('generate');
generatorB.addEventListener("click", async () => {

    try{
        const dat = await apiCall(zipElement.value); //getting the temprature
        //adding date, temprature and status toi the data variable 
        const snd = await sendAllData({   
            date: todayDate, 
            tmp: dat.main.temp,
            status: userContent.value
        });
        console.log(snd);
        await getForUser(); //calling the function to display the data on the screen

    }catch(err){
        console.log("Error is:" + err)
    }
});

//the function which displays data for user
async function getForUser(){
    const req = await fetch('/getAll');
    try{
        const res = await req.json();
        console.log(res);
        //updating UI with data 
        document.getElementById('date').innerHTML = "Date: " + res.date;
        document.getElementById('temp').innerHTML = "Temp: " + res.tmp + " &degF";
        document.getElementById('content').innerHTML = "Status: " + res.status;
        document.getElementById('errorHolder').innerHTML="";

    }catch(err){
        console.log("Error is:" + err)
    }
}

//the funnction to get the temprature through the API call at openweathermap.org
async function apiCall(code){
    const req = await fetch(Link + code + ",&appid=" + Api +"&units=imperial"); 
    try{
        const res = await req.json();
        //handling errors
        if(zipElement.value.trim() == ''){
            document.getElementById('errorHolder').innerHTML = "Enter a 5 no. ZipCode!";
            return;
        }
        else if(res.cod != '200'){
            document.getElementById('errorHolder').innerHTML = "City not Found!";
            return;
        }
        else{
            console.log(res);
            return res;
        }
    }catch(err){
        console.log("Error is:" + err)
    }
}

//the function which send the collected data
async function sendAllData (dat={}){
    const req = await fetch ('/sendAll' , {
        method: 'POST',
        credentials:'same-origin',
        headers:{'Content-Type':'application/json',}, 
        body: JSON.stringify(dat)
    });
    try{
        const res = await req.json();
        console.log(res);
        return res;
    }catch(err){
        console.log("Error is:" + err)
    }
}
